function myname(){
    alert("Monique");  
}